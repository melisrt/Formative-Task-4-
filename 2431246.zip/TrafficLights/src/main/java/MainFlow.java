import swiftbot.*;

public class MainFlow {
public static long totalTime = 0; 
	static SwiftBotAPI swiftbot;

	public static void main(String[] args) throws InterruptedException {
		long start = System.currentTimeMillis(); 
		try {
			swiftbot = new SwiftBotAPI();
		} catch (Exception e) {
			/*
			 * Outputs a warning if I2C is disabled. This only needs to be turned on once,
			 * so you won't need to worry about this problem again!
			 */
			System.out.println("\nI2C disabled!");
			System.out.println("Run the following command:");
			System.out.println("sudo raspi-config nonint do_i2c 0\n");
			System.exit(5);
		}
		enableButton();
		long end = System.currentTimeMillis();
		double totalmain = (end-start) / 1000.0; 
		totalTime += totalmain; 
	}

	public static void enableButton() {
		long start = System.currentTimeMillis(); 
		System.out.println("Press button 'A' to start");
		System.out.println("Press button 'X' to go to execution log");
		System.out.println();
		System.out.println("\r\n"
				+ "   /$$                         /$$$$$$   /$$$$$$  /$$                 /$$ /$$           /$$         /$$    \r\n"
				+ "  | $$                        /$$__  $$ /$$__  $$|__/                | $$|__/          | $$        | $$    \r\n"
				+ " /$$$$$$    /$$$$$$  /$$$$$$ | $$  \\__/| $$  \\__/ /$$  /$$$$$$$      | $$ /$$  /$$$$$$ | $$$$$$$  /$$$$$$  \r\n"
				+ "|_  $$_/   /$$__  $$|____  $$| $$$$    | $$$$    | $$ /$$_____/      | $$| $$ /$$__  $$| $$__  $$|_  $$_/  \r\n"
				+ "  | $$    | $$  \\__/ /$$$$$$$| $$_/    | $$_/    | $$| $$            | $$| $$| $$  \\ $$| $$  \\ $$  | $$    \r\n"
				+ "  | $$ /$$| $$      /$$__  $$| $$      | $$      | $$| $$            | $$| $$| $$  | $$| $$  | $$  | $$ /$$\r\n"
				+ "  |  $$$$/| $$     |  $$$$$$$| $$      | $$      | $$|  $$$$$$$      | $$| $$|  $$$$$$$| $$  | $$  |  $$$$/\r\n"
				+ "   \\___/  |__/      \\_______/|__/      |__/      |__/ \\_______/      |__/|__/ \\____  $$|__/  |__/   \\___/  \r\n"
				+ "                                                                              /$$  \\ $$                    \r\n"
				+ "                                                                             |  $$$$$$/                    \r\n"
				+ "                                                                              \\______/                     \r\n"
				+ "");
		System.out.println();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		swiftbot.enableButton(Button.A, () -> {
			System.out.println("Game Started!");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			buttonA();
		});
		swiftbot.enableButton(Button.X, () -> {
			ExecutionLog.LogButton(); 
		});
		swiftbot.enableButton(Button.Y, () -> {
			System.out.println("Enter Valid Input, please choose from the list!");
		});
		swiftbot.enableButton(Button.B, () -> {
			System.out.println("Enter Valid Input, please choose from the list!");
		});
	}

	public static void buttonA() {
		int[] Y = { 255, 255, 0 };
		swiftbot.fillUnderlights(Y);
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		swiftbot.startMove(35, 40);
		System.out.println("Initial speed: 19cm/s");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		ImageCapture.getRGB();
	}
}

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import swiftbot.Button;

public class ExecutionLog {
	private static String Logfile = "Trafficlightlog.txt";

	public static void LogButton() {

		MainFlow.swiftbot.disableAllButtons();
		System.out.println("-----------------------------------");
		System.out.println();
		System.out.println("Execution Log");
		System.out.println();
		System.out.println("-----------------------------------");
		System.out.println("Press button 'Y' to view log");
		System.out.println("Press button 'X' to skip log");

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.enableButton(Button.A, () -> {
			System.out.println("Wrong button");
		});
		MainFlow.swiftbot.enableButton(Button.B, () -> {
			System.out.println("Wrong button");
		});
		MainFlow.swiftbot.enableButton(Button.Y, () -> {
			buttonY();
		});
		MainFlow.swiftbot.enableButton(Button.X, () -> {
			buttonX(); 
		});
	}
	public static void buttonY() {
		System.out.println("Total Lights: "+allLights.totalLights);
		System.out.println("Most frequent colour: "+allLights.MostFrequentCol);
		System.out.println("Number of Most Frequent: "+allLights.NumOfMostFrequent);
		System.out.println("Total time: "+MainFlow.totalTime + " " + "Seconds");
		SavingTheLog();
		System.exit(0);
	}
	public static void SavingTheLog () {
		boolean RedAppending = allLights.RedNo !=0;
		boolean GreenAppending = allLights.BlueNo !=0;
		boolean BlueAppending = allLights.GreenNo !=0;

		try (FileWriter LogFile = new FileWriter(Logfile, RedAppending && GreenAppending && BlueAppending);
				BufferedWriter addlog = new BufferedWriter(LogFile)) {
			if (!RedAppending && GreenAppending && BlueAppending) {
				addlog.write("Traffic light run information Log/n");
			}

			addlog.write("******** Most common colour = " + allLights.MostFrequentCol + "\n" + "/////");
			addlog.write("******** Number of times the common colour was encountered: " + allLights.NumOfMostFrequent++ + "\n");
			addlog.write("********Number of traffic lights encountered = " + allLights.totalLights++ + "\n");
			addlog.write("Total execution time of program =" +MainFlow.totalTime + " "+ "Seconds");
			addlog.flush();
			System.out.println("");
			System.out.println("********The file is located at: " + new File(Logfile).getAbsolutePath() + "********");
			System.out.println("File has been saved");
		}catch (IOException e) {
			System.out.println("Error: details were not saved properly");


		}
	}
	public static void buttonX() {
		SavingTheLog(); 
		System.exit(0);
	}



}







import swiftbot.*;
import java.util.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.image.BufferedImage;

public class SnakesandLadders {
	// Create instance of SwiftBot API for robot control
	private static SwiftBotAPI swiftBot;
	
	// Define board dimensions: 5x5 grid
	private static final int BOARD_SIZE = 5;
	private static final int TOTAL_SQUARES = BOARD_SIZE * BOARD_SIZE;  // 25 squares total
	private static final String SWIFTBOT_NAME = "SwiftBot";  // Robot's name
	
	// Board elements
	private static int[][] board = new int[BOARD_SIZE][BOARD_SIZE];  // 2D array representing the board
	private static Map<Integer, Integer> snakes = new HashMap<>();  // Maps snake heads to tails
	private static Map<Integer, Integer> ladders = new HashMap<>();  // Maps ladder bottoms to tops
		
	// Player state variables
	private static String playerName;  // Stores the human player's name from QR code
	private static int playerPosition = 1;  // Start both players at square 1
	private static int swiftBotPosition = 1;
	private static boolean isPlayerTurn = false;  // Will be decided by initial dice roll
	
	// Button interaction tracking
	private static boolean buttonPressed = false;  // Flag for button press detection
	private static Button lastPressedButton = null;  // Stores which button was last pressed
	
	// Game tracking variables
	private static int lastRoll;  // Stores the most recent dice roll
	private static List<String> diceRollHistory = new ArrayList<>();  // Records all dice rolls
	private static Scanner scanner;  // For reading user input
	
	public static void main(String args[]) throws InterruptedException {
		try {
			initialize();  // Setup SwiftBot and game components
			startGame();   // Begin the main game loop
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			cleanup();  // Ensure proper resource cleanup
		}
	}
	
	private static void initialize() {
		try {
			swiftBot = new SwiftBotAPI();  // Initialize robot control
			setupButtons();  // Configure button handlers
			scanner = new Scanner(System.in);  // Setup input scanner
		} catch (Exception e) {
			System.out.println("Failed to initialize SwiftBot: " + e.getMessage());
			System.exit(1);
		}
	}
	
	//Button methods
	private static void setupButtons() {
		// Y button - Start game
		swiftBot.enableButton(Button.Y, () -> {
			System.out.println("Button Y is pressed, starting the game...");
			lastPressedButton = Button.Y;
			buttonPressed = true;
		});

		// A button - Roll dice
		swiftBot.enableButton(Button.A, () -> {
			lastPressedButton = Button.A;
			buttonPressed = true;
		});

		// X button - Quit game and save state
		swiftBot.enableButton(Button.X, () -> {
			System.out.println("Button X is pressed, quitting the game...");
			try {
				saveGameState();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Runtime.getRuntime().halt(0);  // Force immediate exit
		});

	}
	
	private static void waitForButton(Button button) throws InterruptedException {
		// Reset button state
		buttonPressed = false;
		lastPressedButton = null;
		// Wait until the specific button is pressed
		while(!buttonPressed || lastPressedButton != button) {
			Thread.sleep(100);
		}
	}

	//Core game methods
	private static void startGame() throws InterruptedException {
		// Game flow sequence
		displayWelcomeScreen();  // Show welcome message
		waitForButton(Button.Y);  // Wait for player to start
		
		displayQRInstructions();  // Show QR code scanning instructions
		playerName = scanQRCode();  // Get player name from QR code
		
		displayGameInstructions();  // Explain game rules
		
		setupBoard();  // Initialize board with snakes and ladders
		Thread.sleep(2000);  // Pause for players to see board
		
		displayFirstPlayerDecision();  // Determine who goes first
		
		// Main game loop
		while (true) {
			clearScreen();
			
			if (isPlayerTurn) {
				playerTurn();  // Handle player's turn
			} else {
				swiftBotTurn();  // Handle SwiftBot's turn
			}
			
			if (checkWinner()) {  // Check if someone won
				break;
			}
			
			isPlayerTurn = !isPlayerTurn;  // Switch turns
			Thread.sleep(1500);  // Pause between turns
		}
	}
	
	private static String scanQRCode() {
		String defaultName = "Player1";  // Fallback name if QR scan fails
		int maxAttempts = 5;  // Maximum number of scan attempts
		int attempts = 0;
		
		while(attempts < maxAttempts) {
			try {
				// Capture QR image from SwiftBot's camera
				BufferedImage img = swiftBot.getQRImage();
				// Try to decode the QR code
				String qrText = swiftBot.decodeQRImage(img);
				
				if (!qrText.isEmpty()) {
					// Check if name is too long (max 10 characters)
					if (qrText.length() > 10) {
						System.out.println("\nSorry! The name is too long (maximum 10 characters).");
						System.out.println("Please create a new QR code with a shorter name.");
						System.out.println("Attempt " + (attempts + 1) + " of " + maxAttempts);
						Thread.sleep(3000); // Wait 3 seconds before next attempt
						attempts++;
						continue;
					}
					return qrText;  // Return valid name from QR code
				}
				System.out.println("QR code not detected. Please try again. " + 
						"Attempt " + (attempts + 1) + " of " + maxAttempts);
				Thread.sleep(3000); // Wait 3 seconds before next attempt
			} catch (IllegalArgumentException e) {
				System.out.println("Error capturing QR code: Empty image");
			} catch (Exception e) {
				System.out.println("Error scanning QR code");
			}
			attempts++;
		}
		
		// If all attempts fail, use default name
		System.out.println("Could not read QR code. Using default name: " + defaultName);
		return defaultName;
	}
	
	private static int rollDice() {
		// Generate random number between 1 and 6
		return new Random().nextInt(6) + 1;
	}
	
	private static void displayFirstPlayerDecision() throws InterruptedException {
		clearScreen();
		int playerRoll, swiftBotRoll;
		
		do {
			System.out.println("\nPress Button 'A' to roll the die.");
			waitForButton(Button.A);
			
			playerRoll = rollDice();
			System.out.printf("\n%s rolled %d\n", playerName, playerRoll);
			displayDice(playerRoll);
			Thread.sleep(1500);
			
			swiftBotRoll = rollDice();
			System.out.printf("\nSwiftBot rolled %d\n", swiftBotRoll);
			displayDice(swiftBotRoll);
			Thread.sleep(1500);
			
			if (playerRoll == swiftBotRoll) {
				System.out.println("\nIt's a tie! Let's roll again.");
				Thread.sleep(1500);
			}
		} while (playerRoll == swiftBotRoll);
		
		isPlayerTurn = playerRoll > swiftBotRoll;
		if (isPlayerTurn) {
			System.out.println("\nCongratulations you rolled higher than SwiftBot. You are starting first!");
		} else {
			System.out.println("\nSwiftBot rolled higher. SwiftBot starts first!");
			Thread.sleep(2000);
		}
	}

	private static void playerTurn() throws InterruptedException {
		clearScreen();
		System.out.println("\nPress Button 'A' to roll the die.");
		waitForButton(Button.A);  // Wait for player to press A button
		
		int roll = rollDice();  // Get random dice roll
		int oldPosition = playerPosition;  // Store current position
		int newPosition = calculateNewPosition(playerPosition, roll);  // Calculate new position
		
		// Record the dice roll in history
		diceRollHistory.add(String.format("%s rolled %d: %d -> %d", 
					   playerName, roll, oldPosition, newPosition));
		
		// Display dice roll
		displayDice(roll);
		
		// Display move message based on roll outcome
		if (oldPosition + roll > TOTAL_SQUARES) {
			// If roll is too high to land exactly on final square
			System.out.printf("\n%s rolled %d and moved from square %d to ... ups! You need to roll a %d to win.", 
							playerName, roll, oldPosition, TOTAL_SQUARES - oldPosition);
			System.out.println(" It's SwiftBot's turn!");
		} else {
			// Normal move
			System.out.printf("\n%s rolled %d and moved from square %d to square %d!", 
							playerName, roll, oldPosition, newPosition);
		}
		
		// Update position if valid move
		if (newPosition != oldPosition) {
			playerPosition = newPosition;
			checkSnakesAndLadders(true);  // Check if landed on snake or ladder
		}
		
		displayBoardSetup();
		Thread.sleep(1000);
		
		// Update the roll tracking
		lastRoll = roll;
	}

	private static void swiftBotTurn() throws InterruptedException {
		clearScreen();
		Thread.sleep(1000);
		
		int roll = rollDice();  // Get random dice roll
		int oldPosition = swiftBotPosition;  // Store current position
		int newPosition = calculateNewPosition(swiftBotPosition, roll);  // Calculate new position
		
		// Record the dice roll in history
		diceRollHistory.add(String.format("%s rolled %d: %d -> %d", 
					   SWIFTBOT_NAME, roll, oldPosition, newPosition));
		
		// Display dice roll
		displayDice(roll);
		
		// Display move message based on roll outcome
		if (oldPosition + roll > TOTAL_SQUARES) {
			// If roll is too high to land exactly on final square
			System.out.printf("\nSwiftBot rolled %d and moved from square %d to ... ups! SwiftBot needs to roll a %d to win.", 
							roll, oldPosition, TOTAL_SQUARES - oldPosition);
			System.out.println(" It's " + playerName + "'s turn!");
		} else {
			// Normal move
			System.out.printf("\nSwiftBot rolled %d and moved from square %d to square %d!", 
							roll, oldPosition, newPosition);
		}
		
		// Update position if valid move
		if (newPosition != oldPosition) {
			moveSwiftBot(oldPosition, newPosition, false);  // Move the physical robot
			swiftBotPosition = newPosition;
			checkSnakesAndLadders(false);  // Check if landed on snake or ladder
		}

		displayBoardSetup();
		Thread.sleep(1000);
		
		// Update the roll tracking
		lastRoll = roll;
	}
	
	private static boolean checkWinner() throws InterruptedException {
		if (playerPosition == TOTAL_SQUARES) {
			// Player wins
			clearScreen();
			displayDice(lastRoll);
			System.out.printf("\n%s rolled %d and moved from square %d to square %d!\n", 
							playerName, lastRoll, TOTAL_SQUARES - lastRoll, TOTAL_SQUARES);
			
			clearScreen();
			System.out.println("\nYOU WON CONGRATULATIONSSS :) SEE YOU AGAIN CHAMP!");
			
			// Display both ASCII patterns
			System.out.println("\n  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.");
			System.out.println(" / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ /___)~");
			System.out.println("`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'         ");
			
			System.out.println("\n------------------------------------------------");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("------------------------------------------------");
			
			celebrate();
			saveGameState();
			return true;
		} else if (swiftBotPosition == TOTAL_SQUARES) {
			// SwiftBot wins
			clearScreen();
			displayDice(lastRoll);
			System.out.printf("\nSwiftBot rolled %d and moved from square %d to square %d!\n", 
							lastRoll, TOTAL_SQUARES - lastRoll, TOTAL_SQUARES);
			
			clearScreen();
			System.out.println("\nSWIFTBOT WINS! HE SAYS HE WOULD LIKE TO PLAY WITH YOU AGAIN :)");
			
			// Display both ASCII patterns
			System.out.println("\n  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.");
			System.out.println(" / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ /___)~");
			System.out.println("`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'         ");
			
			System.out.println("\n------------------------------------------------");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("------------------------------------------------");
			
			celebrate();
			saveGameState();
			return true;
		}
		return false;
	}
	
	//Board management methods
	private static void setupBoard() throws InterruptedException {
		// Initialize the board with numbers 1-25 in a snake pattern
		int value = 1;
		for (int i = 0; i < BOARD_SIZE; i++) {
			if (i % 2 == 0) {
				// Left to right numbering (1-5, 11-15, 21-25)
				for (int j = 0; j < BOARD_SIZE; j++) {
					board[i][j] = value++;
				}
			} else {
				// Right to left numbering (10-6, 20-16)
				for (int j = BOARD_SIZE - 1; j >= 0; j--) {
					board[i][j] = value++;
				}
			}
		}
		
		// Place snakes and ladders randomly on the board
		placeSnakesAndLadders();
		System.out.println("\nRandomly placing snakes and ladders on the board...");
		displayBoardSetup();
	}
	
	
	private static void placeSnakesAndLadders() {
		Random random = new Random();
		int attempts = 0;
		int maxAttempts = 100;  // Prevent infinite loops
		
		// Place 2 ladders
		while (ladders.size() < 2 && attempts < maxAttempts) {
			// Bottom should be between 2 and 20 (not on square 1, and ensuring top is below 25)
			int bottom = random.nextInt(19) + 2;
			// Top should be at least BOARD_SIZE squares higher but below 25
			int maxTop = Math.min(24, bottom + 10);  // Ensure top is below 25
			int minTop = bottom + BOARD_SIZE;
			if (maxTop <= minTop) continue;  // Skip if no valid top position possible
			
			int top = random.nextInt(maxTop - minTop + 1) + minTop;
			
			// Check if this ladder position is valid
			if (isValidLadderPosition(bottom, top)) {
				ladders.put(bottom, top);
			}
			attempts++;
		}
		
		// Reset attempts counter for snakes
		attempts = 0;
		
		// Place 2 snakes
		while (snakes.size() < 2 && attempts < maxAttempts) {
			// Head should be between 6 and 24 (not on 25 and allowing room for tail)
			int head = random.nextInt(19) + 6;
			// Tail should be between 2 and (head-1) (not on square 1)
			int tail = random.nextInt(head - 2) + 2;
			
			// Check if this snake position is valid
			if (isValidSnakePosition(head, tail)) {
				snakes.put(head, tail);
			}
			attempts++;
		}
		
		// If we couldn't place all snakes and ladders, try again
		if (snakes.size() != 2 || ladders.size() != 2) {
			snakes.clear();
			ladders.clear();
			placeSnakesAndLadders();
		}
	}
	
	
	private static boolean isValidLadderPosition(int bottom, int top) {
		// Calculate row positions
		int bottomRow = (bottom - 1) / BOARD_SIZE;
		int topRow = (top - 1) / BOARD_SIZE;
		
		// Check multiple conditions for valid ladder placement:
		return bottomRow != topRow &&  // Not in same row
			   bottom != 1 &&  // Not on first square
			   !ladders.containsKey(bottom) && !ladders.containsValue(top) &&  // No ladder overlap
			   !snakes.containsKey(bottom) && !snakes.containsKey(top) &&  // No snake heads
			   !snakes.containsValue(bottom) && !snakes.containsValue(top) &&  // No snake tails
			   !ladders.containsValue(bottom) && !ladders.containsKey(top);  // No other ladder overlap
	}
	
	
	private static boolean isValidSnakePosition(int head, int tail) {
		// Calculate row positions
		int headRow = (head - 1) / BOARD_SIZE;
		int tailRow = (tail - 1) / BOARD_SIZE;
		
		// Check multiple conditions for valid snake placement:
		return headRow != tailRow &&  // Not in same row
			   tail != 1 &&  // Not on first square
			   !snakes.containsKey(head) && !snakes.containsValue(tail) &&  // No snake overlap
			   !ladders.containsKey(head) && !ladders.containsKey(tail) &&  // No ladder bottoms
			   !ladders.containsValue(head) && !ladders.containsValue(tail) &&  // No ladder tops
			   !snakes.containsValue(head) && !snakes.containsKey(tail);  // No other snake overlap
	}
	
	
		

	//Movement and calculation methods
	
	private static int calculateNewPosition(int currentPos, int roll) {
		int newPos = currentPos + roll;
		// Modified to require exact landing on square 25
		return (newPos == TOTAL_SQUARES) ? newPos :  // If exactly 25, allow move
			   (newPos > TOTAL_SQUARES) ? currentPos :  // If over 25, stay in place
			   newPos;  // Otherwise, move to new position
	}
	
	
	private static void checkSnakesAndLadders(boolean isPlayer) throws InterruptedException {
		int currentPosition = isPlayer ? playerPosition : swiftBotPosition;
		
		// Check for snakes
		if (snakes.containsKey(currentPosition)) {
			int newPosition = snakes.get(currentPosition);
			// Display snake alert and ASCII art
			Thread.sleep(200);
			System.out.println("\nUH OH SNAKE ALERT!");
			Thread.sleep(200);
			System.out.println("\n  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.");
			System.out.println(" / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ /___)~");
			System.out.println("`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'         ");
			Thread.sleep(200);
			System.out.printf("\nGoing back to square %d :( ", newPosition);
			
			if (!isPlayer) {
				// Execute 180-degree turn for SwiftBot
				rotate180Degrees();
				Thread.sleep(500);
				
				// Move to snake's tail position
				moveSwiftBot(currentPosition, newPosition, true);
				swiftBotPosition = newPosition;
				System.out.println("It's " + playerName + "'s turn!");
			} else {
				playerPosition = newPosition;
				System.out.println("It's SwiftBot's turn!");
			}

		}
		
		// Check for ladders
		if (ladders.containsKey(currentPosition)) {
			int newPosition = ladders.get(currentPosition);
			// Display ladder alert and ASCII art
			Thread.sleep(200);
			System.out.println("\nIT'S CLIMBING TIME!");
			Thread.sleep(200);
			System.out.println("\n------------------------------------------------");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("------------------------------------------------");
			Thread.sleep(200);
			System.out.printf("\nGoing up to square %d!! ", newPosition);
			
			if (isPlayer) {
				playerPosition = newPosition;
				System.out.println("It's SwiftBot's turn!");
			} else {
				moveSwiftBot(currentPosition, newPosition, false);
				swiftBotPosition = newPosition;
				System.out.println("It's " + playerName + "'s turn!");
			}
		}
	}
	
	
	private static void moveSwiftBot(int fromPosition, int toPosition, boolean isSnake) {
		try {
			// Movement speed and timing constants
			int speed = 30;
			int oneSquareTime = 1450;  // 1.45 seconds per square
			
			// For snake movement, initial 180-degree turn
			if (isSnake) {
				rotateSwiftBot(180);
				Thread.sleep(1000);
			}
			
			while (isSnake ? fromPosition > toPosition : fromPosition < toPosition) {
				// Right edges (5, 15) - different turns for snake/ladder movement
				if (fromPosition == 5 || fromPosition == 15) {
					// Snake: turn right, move forward, turn right
					// Normal: turn left, move forward, turn left
					if (isSnake) {
						rotateSwiftBot(-90);
					
						swiftBot.move(speed, speed, oneSquareTime);
						Thread.sleep(oneSquareTime + 100);
						
						rotateSwiftBot(-90);
					} else {
						rotateSwiftBot(90);
						
						swiftBot.move(speed, speed, oneSquareTime);
						Thread.sleep(oneSquareTime + 100);
						
						rotateSwiftBot(90);
					}
					fromPosition = isSnake ? fromPosition - 1 : fromPosition + 1;
				}
				
				// Left edges (10, 20) - different turns for snake/ladder movement
				else if (fromPosition == 10 || fromPosition == 20) {
					// Snake: turn left, move forward, turn left
					// Normal: turn right, move forward, turn right
					if (isSnake) {
						rotateSwiftBot(90);
						
						swiftBot.move(speed, speed, oneSquareTime);
						Thread.sleep(oneSquareTime + 100);
						
						rotateSwiftBot(90);
					} else {
						rotateSwiftBot(-90);
						
						swiftBot.move(speed, speed, oneSquareTime);
						Thread.sleep(oneSquareTime + 100);
						
						rotateSwiftBot(-90);
					}
					fromPosition = isSnake ? fromPosition - 1 : fromPosition + 1;
				}
				
				// Regular movement or at column starts (6, 11, 16, 21)
				else {
					// Calculate next edge based on current position
					int nextEdge;
					if (fromPosition < 6) nextEdge = 5;
					else if (fromPosition < 11) nextEdge = 10;
					else if (fromPosition < 16) nextEdge = 15;
					else if (fromPosition < 21) nextEdge = 20;
					else nextEdge = 25;
					
					// Calculate squares to move based on movement type
					int squaresToMove;
					if (isSnake) {
						// For snake: move backwards to next lower edge or target
						squaresToMove = fromPosition - Math.max(toPosition, nextEdge - 5);
					} else {
						// For normal/ladder: move forward to next edge or target
						squaresToMove = Math.min(toPosition, nextEdge) - fromPosition;
					}
					
					// Execute movement if needed
					if (squaresToMove > 0) {
						swiftBot.move(speed, speed, oneSquareTime * squaresToMove);
						Thread.sleep(oneSquareTime * squaresToMove + 100);
						fromPosition = isSnake ? fromPosition - squaresToMove : fromPosition + squaresToMove;
					}
				}
			}
			
			// For snake movement, final 180-degree turn
			if (isSnake) {
				rotateSwiftBot(180);
				Thread.sleep(1000);
			}
			
		} catch (Exception e) {
			System.out.println("Error moving SwiftBot: " + e.getMessage());
		}
	}
	
	
	private static void rotateSwiftBot(double angle) throws InterruptedException {
		int rotationSpeed = 30;
		int rotationTime = 650;  // Using the specified timing for 90-degree turns
		
		if (angle > 0) {
			// Left turn (counterclockwise)
			swiftBot.move(-rotationSpeed, rotationSpeed, rotationTime);
		} else {
			// Right turn (clockwise)
			swiftBot.move(rotationSpeed, -rotationSpeed, rotationTime);
		}
		Thread.sleep(rotationTime + 100);  // Wait for rotation to complete plus buffer
	}
	
	
	private static void rotate180Degrees() throws InterruptedException {
		int rotationSpeed = 30;
		int rotationTime = 1200;  // Using the specified timing for 180-degree turn
		swiftBot.move(-rotationSpeed, rotationSpeed, rotationTime);
		Thread.sleep(rotationTime + 100);
	}
	

	//Display methods
	private static void displayWelcomeScreen() throws InterruptedException {
		clearScreen();
		System.out.println("\nWELCOME TO SNAKES AND LADDERS");
		System.out.println("\n  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.");
		System.out.println(" / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ /___)~");
		System.out.println("`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'         ");
		Thread.sleep(1000);
		System.out.println("\n\nPRESS 'Y' LOCATED ON THE SWIFTBOT RIGHT HERE TO START THE GAME");
		System.out.println("\n");
		System.out.println("      ---------------");
		System.out.println("      |             |");
		System.out.println("    --|             |--");
		System.out.println("    |                 |");
		System.out.println("    |     SwiftBot    |");
		System.out.println("    |                 |");
		System.out.println("    |      A   X      |");
		System.out.println("    |                 |");
		System.out.println("    |      B   Y <---------");
		System.out.println("    |                 |");
		System.out.println("    |-----------------|");
	}
	
	
	private static void displayQRInstructions() throws InterruptedException {
		clearScreen();
		System.out.println("\nGreat! Now you need to scan a QR Code to SwiftBot containing your name");
		System.out.println("so that it can also learn your name :)");
		Thread.sleep(2000);
		System.out.println("\nIf you don't have a QR Code don't worry! You can go to https://qr.io/");
		System.out.println("and create a QR Code by choosing text option and writing your preferred user");
		System.out.println("name.");
		Thread.sleep(2000);
		
		System.out.println("\nAre you ready to scan? Type 'y' for yes and 'n' for no.");
		while (true) {
			String response = scanner.nextLine().toLowerCase();
			if (response.equals("y")) {
				System.out.println("\nGreat! Please show your QR code to SwiftBot's camera.");
				break;
			} else if (response.equals("n")) {
				System.out.println("\nOkay, take your time! Type 'y' when you're ready.");
			} else {
				System.out.println("\nPlease type 'y' for yes or 'n' for no.");
			}
		}
	}
	
	
	private static void displayGameInstructions() throws InterruptedException {
		clearScreen();
		System.out.println("\nHello " + playerName + "! I am SwiftBot, your game buddy :) Before we start the game, let me quickly explain how the game works:");
		Thread.sleep(3000);
		System.out.println("\nWe will each take turns rolling a die to decide how many squares to move forward.");
		Thread.sleep(3000);
		System.out.println("\nYou'll press the button 'A' to roll for yourself, and I'll roll automatically on my turn.");
		Thread.sleep(3000);
		System.out.println("\nWe start at square 1, and the goal is to reach square 25 first.");
		Thread.sleep(3000);
		System.out.println("\nWatch out for snakes! If you land on a snake's head, you'll slide down to its tail.");
		Thread.sleep(3000);
		System.out.println("\nBut don't worry, ladders can help! Land on the bottom of a ladder, and you'll climb to the top.");
		Thread.sleep(3000);
		System.out.println("\nThe first player to land exactly on square 25 wins the game!");
		Thread.sleep(3000);
		System.out.println("\nBut if you roll too high to land exactly on square 25, you'll stay where you are and try again on your next turn -_-");
		Thread.sleep(3000);
		System.out.println("\nIf you want to quit before the game ends, just press the button 'X'.");
		Thread.sleep(3000);
		System.out.println("\nNow, we roll the die to decide who starts first. Good luck!");
		Thread.sleep(3000);
		System.out.println("\nAre you ready? Type 'y' for yes and 'n' for no.");
		
		while (true) {
			String response = scanner.nextLine().toLowerCase();
			if (response.equals("y")) {
				System.out.println("\nGreat let's start!!!");
				break;
			} else if (response.equals("n")) {
				System.out.println("\nOkay, take your time! Type 'y' when you're ready.");
			} else {
				System.out.println("\nPlease type 'y' for yes or 'n' for no.");
			}
		}
	}
	
	
	private static void displayBoardSetup() throws InterruptedException {
		System.out.println("\n  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.");
		System.out.println(" / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ /___)~");
		System.out.println("`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'         ");
		Thread.sleep(3000);
		System.out.println("\nThe board looks like this:");
		
		// Print the top border
		printHorizontalBorder();
		
		// Print each row from top to bottom
		for (int i = BOARD_SIZE - 1; i >= 0; i--) {
			StringBuilder row = new StringBuilder();
			
			for (int j = 0; j < BOARD_SIZE; j++) {
				int square = board[i][j];
				row.append("| ");
				
				// Add number with any special markers
				String squareStr = String.format("%-2d", square);
				
				// Check for player positions
				if (square == playerPosition) {
					squareStr = "P" + squareStr;
				}
				if (square == swiftBotPosition) {
					squareStr = "S" + squareStr;
				}
				
				// Check for snakes
				if (snakes.containsKey(square)) {
					squareStr = "H" + squareStr;
				}
				if (snakes.containsValue(square)) {
					squareStr = "T" + squareStr;
				}
				
				// Check for ladders
				if (ladders.containsValue(square)) {
					squareStr = "L" + squareStr;
				}
				if (ladders.containsKey(square)) {
					squareStr = "B" + squareStr;
				}
				
				row.append(String.format("%-3s", squareStr)).append(" ");
			}
			row.append("|");
			
			System.out.println(row.toString());
			printHorizontalBorder();
		}
		
		// Print legend
		System.out.println("\nP is " + playerName + ".");
		System.out.println("S is SwiftBot.");
		System.out.println("H means Snake Head.");
		System.out.println("T means Snake Tail.");
		System.out.println("L means Ladder Top.");
		System.out.println("B means Ladder Bottom.");
		Thread.sleep(5000);
	}
	
	
	private static void printHorizontalBorder() {
		StringBuilder border = new StringBuilder("+");
		for (int i = 0; i < BOARD_SIZE; i++) {
			border.append("-----+");
		}
		System.out.println(border.toString());
	}
	
	
	private static void displayDice(int value) {
		System.out.println("+-------+");
		switch (value) {
			case 1:
				System.out.println("|       |");
				System.out.println("|   *   |");
				System.out.println("|       |");
				break;
			case 2:
				System.out.println("| *     |");
				System.out.println("|       |");
				System.out.println("|     * |");
				break;
			case 3:
				System.out.println("| *     |");
				System.out.println("|   *   |");
				System.out.println("|     * |");
				break;
			case 4:
				System.out.println("| *   * |");
				System.out.println("|       |");
				System.out.println("| *   * |");
				break;
			case 5:
				System.out.println("| *   * |");
				System.out.println("|   *   |");
				System.out.println("| *   * |");
				break;
			case 6:
				System.out.println("| *   * |");
				System.out.println("| *   * |");
				System.out.println("| *   * |");
				break;
		}
		System.out.println("+-------+");
	}


	//Utility Methods
	private static void saveGameState() throws InterruptedException {
		try {
			// Generate time stamp for unique filename
			String timestamp = LocalDateTime.now()
				.format(DateTimeFormatter.ofPattern("yyyy.MM.dd.HH.mm.ss"));
			String logFile = "snakes_and_ladders_" + timestamp + ".log";
			
			// Write game state to file
			try (PrintWriter writer = new PrintWriter(new FileWriter(logFile))) {
				writer.println("Game state at " + timestamp);
				writer.println("Player position: " + playerPosition);
				writer.println("SwiftBot position: " + swiftBotPosition);
				writer.println("\nSnakes: " + snakes);
				writer.println("Ladders: " + ladders);
				writer.println("\nDice Roll History:");
				for (String roll : diceRollHistory) {
					writer.println(roll);
				}
			}
			
			// Display goodbye message
			clearScreen();
			Thread.sleep(1000);
			System.out.println("\nOh, SwiftBot is going to miss you :( Don't make him wait too long!");
			System.out.println("Here's the path to the log file containing the game details.");
			System.out.println("\nLog file path: " + logFile);
			System.out.println("\nDon't forget it when you come back!! See you soon :)");
			
			// Display both ASCII patterns
			System.out.println("\n  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.");
			System.out.println(" / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ / / \\ \\ /___)~");
			System.out.println("`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'         ");
			
			System.out.println("\n------------------------------------------------");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("| | | | | | | | | | | | | | | | | | | | | | | |");
			System.out.println("------------------------------------------------");
			
			System.exit(0);
		} catch (IOException e) {
			System.out.println("Error saving game state: " + e.getMessage());
		}
	}
	
	private static void celebrate() throws InterruptedException {
		int[] red = {255,0,0};
		int[] blue = {0,0,255};
		int[] green = {0,255,0};
		int[] white = {255,255,255};
		for (int i = 0; i < 5; i++) {
			swiftBot.fillUnderlights(red);
			Thread.sleep(200);
			swiftBot.fillUnderlights(blue);
			Thread.sleep(200);
			swiftBot.fillUnderlights(green);
			Thread.sleep(200);
			swiftBot.fillUnderlights(white);
			Thread.sleep(200);
			swiftBot.disableUnderlights();
			Thread.sleep(200);
		}
	}
	
	private static void clearScreen() {
		try {
			if (System.getProperty("os.name").contains("Windows")) {
				// If running on Windows:
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			} else {
				// If running on macOS/Linux:
				System.out.print("\033[H\033[2J");
				System.out.flush();
			}
		} catch (Exception e) {
			System.out.println("Error clearing the console.");
		}
	}
	
	
	// Cleanup method to close resources
	private static void cleanup() {
		if (scanner != null) {
			scanner.close();  // Close the Scanner to prevent resource leaks
		}
	}}

// Import libraries 
import swiftbot.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class AlviSearchForLight
{
	// Initialise core system variables
	static SwiftBotAPI swiftBot;
	static Scanner scanner;
	static Random random = new Random();
	static boolean stopRequested = false;
	static boolean endReached = false;
	static boolean longReportDataReached = false;

	// Initialise time related variables
	static long startTime; 
	static long endTime;   

	// Initialise light intensity variables
	static double lightThreshold = 0.0; 
	static double highestLightIntensity = -Double.MAX_VALUE;
	static String highestLightDirection = "None";
	static ArrayList<double[]> lightIntensityRecords = new ArrayList<>();

	// Initialise image processing variables 
	static int totalPixels = 0; 
	static int[][] imageMatrix = null; 

	static int[][] leftColumn = null; 
	static int[][] centreColumn = null; 
	static int[][] rightColumn = null; 

	// Initialise image counting variables
	static int imageCounter = 0;
	static int obstacleImageCounter = 0;
	static ArrayList<String> savedImageList = new ArrayList<>();
	static int[][][] surroundingImages = null;
	static int[][][] detectedObjectImgs = null;

	// Initialise movement variables
	static String movementDirection = "None"; 
	static int swiftBotSpeed = 50;
	static ArrayList<String> movementHistory = new ArrayList<>();
	static String obstructedDirection = null;
	static String[] movementSequence = null;
	static int totalDistance = 0;
	
	// Main function
	public static void main(String[] args) throws InterruptedException
	{
		swiftBot = new SwiftBotAPI();
		scanner = new Scanner(System.in);
		initializeButtons();
   	    displayIntro();		
    }
	
	// Initialise buttons function
    public static void initializeButtons()
	{
    	// Pressing X puts a stop to the program, either during its runtime or after asking the user if they want to see the final logs
    	swiftBot.enableButton(Button.X, () -> 
    	{   
    	    if (endReached || longReportDataReached) 
    	    { 
    	    	System.out.println("Button X pressed...");
    	        System.out.println("Goodbye!");
    	        System.out.println();
    	        System.exit(0);
    	    } 
    	    else 
    	    {
    	        System.out.println("Button X pressed...");
    	        System.out.println("Program stopped.");
    	        System.out.println();
    	        stopRequested = true;
    	    }
    	});
    	
    	// Pressing A begins the program
	    swiftBot.enableButton(Button.A, () -> 
	    {
	        System.out.println("Button A pressed...");
	        System.out.println("Beginning execution.");
	        System.out.println();
	        try 
	        {
	            searchForLight();
	        } 
	        catch (InterruptedException e) 
	        {
	            System.out.println("Error: Execution failed.");
	            System.out.println();
	            e.printStackTrace();
	        }
	    });

	    // Pressing Y either prints the log or the extended log
	    swiftBot.enableButton(Button.Y, () -> 
	    {   
	        if (endReached) 
	        { 
	            System.out.println("Button Y pressed...");
	            System.out.println("Execution logs: ");
	            System.out.println();
	            displayFinalReport();
	        } 
	        else if (longReportDataReached) 
	        {  
	        	System.out.println("-Light intensity records:");
	            for (double[] record : lightIntensityRecords) 
	            {
	                System.out.println("Detection #" + (int)record[0] + " -> Left: " + record[1] + ", Centre: " + record[2] + ", Right: " + record[3]);
	            }
	            System.out.println();
	            
	            System.out.println("-SwiftBot Movement History:");
	            for (String move : movementHistory) {
	                System.out.println(move);
	            }
	            System.out.println();
	            
	            System.out.println("-Saved Images:");
	            for (String everyImage : savedImageList) 
	            {
	                System.out.println(everyImage);
	            }
	            System.out.println();
	            
	            System.out.println("Goodbye!");
    	        System.out.println();
    	        System.exit(0);
	        } 
	        else 
	        {  
	            System.out.println("Y button pressed...");
	            System.out.println("This button does not do anything at the moment.");
	            System.out.println();
	        }
	    });
	}

    // Intro function explaining to the user how the program works and what to press to start and end the program
	public static void displayIntro() throws InterruptedException
	{
		    System.out.println();
	    	System.out.println("Welcome to Alvi's search for light SwiftBot program!");
	    	System.out.println();
	    	System.out.println("Upon pressing Button A, the SwiftBot will begin to move towards the nearest bright light source.");  
	    	System.out.println();
	    	System.out.println("Press Button X at any time to end the program.");  
	    	System.out.println("Press Button A to start the program."); 
	    	System.out.println();
	}
	
	// Main sequence of code
	public static void searchForLight() throws InterruptedException
	{	
		startTime = System.currentTimeMillis(); 
		    
	    int cycleNum = 0;
	    int maxCycles = 1000; 
	    
	    surroundingImages = new int[maxCycles][][];
	    detectedObjectImgs = new int[maxCycles][][]; 
	    movementSequence = new String[maxCycles];
	    obstructedDirection = null;
	    
	    // Main loop for light seeking
	    while (!stopRequested)
	    {
	        cycleNum++;
	       
	        System.out.println("Capturing image...");
	        BufferedImage image = swiftBot.takeStill(ImageSize.SQUARE_720x720);
	        
	        if (image != null) 
	        {
	            String initialImage = "initial_image_" + imageCounter + ".jpg";
	            try 
	            {
	                ImageIO.write(image, "jpg", new File(initialImage));
	                System.out.println("Initial image stored at: " + initialImage + ".");
	                savedImageList.add(initialImage); 
	                imageCounter++; 
	            } 
	            catch (IOException e) 
	            {
	                System.out.println("Error: Failed to store initial image.");
	                e.printStackTrace();
	            }
	        } 

	        else 
	        {
	            System.out.println("Error: Failed to capture initial image.");
	        }
	        
	        System.out.println("Converting image to pixel matrix...");
	        imageMatrix = convertImageToPixelMatrix(image);
	     
	        surroundingImages[cycleNum] = imageMatrix;
	       
	        if (cycleNum == 1)
	        {
	        	System.out.println("Calculating threshold light intensity...");
	            lightThreshold = calculateAverageLightIntensity(imageMatrix);
	        }
	        
	        System.out.println("Dividing pixel matrix into columns...");
	        divideMatrixIntoColumns(imageMatrix);
	        System.out.println();
	       
	        System.out.println("Calculating average light intensity for left column...");
	        double leftIntensity = calculateAverageLightIntensity(leftColumn);
	        System.out.println("Calculating average light intensity for centre column...");
	        double centreIntensity = calculateAverageLightIntensity(centreColumn);
	        System.out.println("Calculating average light intensity for right column...");
	        double rightIntensity = calculateAverageLightIntensity(rightColumn);
	        System.out.println();
	        
	        lightIntensityRecords.add(new double[]{lightIntensityRecords.size() + 1, leftIntensity, centreIntensity, rightIntensity});

	        System.out.println("Determining movement direction...");
	        movementDirection = determineMovementDirection(leftIntensity, centreIntensity, rightIntensity);
	        System.out.println();
	        
	        // Logic for storing light intensities and directions for final report 
	        if (leftIntensity > highestLightIntensity) {
	            highestLightIntensity = leftIntensity;
	            highestLightDirection = "left";
	        }
	        if (centreIntensity > highestLightIntensity) {
	            highestLightIntensity = centreIntensity;
	            highestLightDirection = "centre";
	        }
	        if (rightIntensity > highestLightIntensity) {
	            highestLightIntensity = rightIntensity;
	            highestLightDirection = "right";
	        }
	       
	        // Information printed to console before movement starts
	        displayMiddle(leftIntensity, centreIntensity, rightIntensity, movementDirection, swiftBotSpeed);
	        
	        // Logic for objects being in the way
	        double objectDistance = swiftBot.useUltrasound();
	               
	        if (objectDistance < 50) 
	        {
	        	
	            displayObstacleWarning(objectDistance);
	               
	            objectDistance = swiftBot.useUltrasound();
	            
	            if (objectDistance < 50) 
	            {
	                obstructedDirection = movementDirection; 

	                System.out.println("Capturing image of object in the way...");
	                BufferedImage obstacleImage = swiftBot.takeStill(ImageSize.SQUARE_720x720);
	                System.out.println();
	                
	                if (obstacleImage != null) 
	                {
	                    String objectForlist = "obstacle_image_" + obstacleImageCounter + ".jpg";
	                    try 
	                    {
	                        ImageIO.write(obstacleImage, "jpg", new File(objectForlist));
	                        System.out.println("Obstacle image stored at: " + objectForlist + ".");
	                        savedImageList.add(objectForlist); 
	                        obstacleImageCounter++; 
	                    } 
	                    catch (IOException e) 
	                    {
	                        System.out.println("Error: Failed to store obstacle image.");
	                        e.printStackTrace();
	                    }
	                } 

	                
	                else 
	                {
	                    System.out.println("Error: Failed to capture obstacle image.");
	                }

	                detectedObjectImgs[cycleNum] = convertImageToPixelMatrix(obstacleImage);

	                movementDirection = determineMovementDirection(leftIntensity, centreIntensity, rightIntensity);

	                System.out.println("Obstacle is still in the way. Changing direction to: " + movementDirection + ".");

	                swiftBotMovement(movementDirection);
	                
	                continue; 
	            }
	        }
	       
	        // The SwiftBot moves towards the direction with the highest light intensity if it's significant in comparison to the threshold intensity, and if it isn't then it enters wandering mode
	        System.out.println("Processing image...");
	        if (movementDirection != null && Math.max(Math.max(leftIntensity, centreIntensity), rightIntensity) >= 1.05 * lightThreshold)
	        {
	            swiftBotMovement(movementDirection);
	        }
	        else
	        {
	            swiftBotWander();
	        }
	       
	        movementSequence[cycleNum] = movementDirection;
	     
	        if (stopRequested)
	        {
	            break;
	        }
	    }
	   
	    displayFinishingQuestion();
	}
	
	// Each pixel of image is turned into a coordinate in a pixel array
	public static int[][] convertImageToPixelMatrix(Object image)
	{
		if (image == null || !(image instanceof BufferedImage))
	    {
	        throw new IllegalArgumentException("Error: Image is null or incorrect type.");
	    }
      
       BufferedImage bufferedImage = (BufferedImage) image;
       
       int width = bufferedImage.getWidth();
       int height = bufferedImage.getHeight();
       int[][] imageMatrix = new int[height][width]; 

       for (int y = 0; y < height; y++)  
       {
           for (int x = 0; x < width; x++) 
           {
               imageMatrix[y][x] = bufferedImage.getRGB(x, y); 
           }
       }
      
       return imageMatrix;
   }	
	
   // Each coordinate of array is extracted as RGB value and used to calculate the average light intensity of the entire pixel matrix	
   public static double calculateAverageLightIntensity(int[][] imageMatrix)
   {
       int height = imageMatrix.length;
       int width = imageMatrix[0].length;
       double totalLightIntensity = 0.0;
       int totalPixels = height * width;
       
       for (int i = 0; i < height; i++)
       {
           for (int j = 0; j < width; j++)
           {
               int pixel = imageMatrix[i][j];
              
               int red = (pixel >> 16) & 0xFF;
               int green = (pixel >> 8) & 0xFF;
               int blue = pixel & 0xFF;
               double tempLightIntensity = (0.2126 * red) + (0.7152 * green) + (0.0722 * blue);
             
               totalLightIntensity += tempLightIntensity;
           }
       }
       
       return totalLightIntensity / totalPixels;
   }
   
   // Pixel matrix is segmented into three seperate columns
   public static void divideMatrixIntoColumns(int[][] imageMatrix)
   {
       int matrixRowLength = imageMatrix.length;
       int matrixRowWidth = imageMatrix[0].length;
       int matrixSliceWidth = matrixRowWidth / 3;
      
       leftColumn = new int[matrixRowLength][matrixSliceWidth];
       centreColumn = new int[matrixRowLength][matrixSliceWidth];
       rightColumn = new int[matrixRowLength][matrixSliceWidth];
      
       for (int y = 0; y < matrixRowLength; y++)
       {
           for (int x = 0; x < matrixSliceWidth; x++)
           {
               leftColumn[y][x] = imageMatrix[y][x];
               centreColumn[y][x] = imageMatrix[y][x + matrixSliceWidth];
               rightColumn[y][x] = imageMatrix[y][x + 2 * matrixSliceWidth];
           }
       }
       
   }
   
   // Movement direction is decided based on which direction has the highest light intensity.
   public static String determineMovementDirection(double leftIntensity, double centreIntensity, double rightIntensity)
   {
	   // Logic for picking direction if every direction has the same intensity
       if (leftIntensity == centreIntensity && centreIntensity == rightIntensity)
       {
           String[] options = {"left", "centre", "right"};
           return options[random.nextInt(options.length)];
       }
       
       // Logic for deciding highest and second highest light intensities for if there is an object in the way
       double maxIntensity = Math.max(leftIntensity, Math.max(centreIntensity, rightIntensity));
       double secondMaxIntensity = Double.MIN_VALUE;

       boolean leftMax = (leftIntensity == maxIntensity);
       boolean centreMax = (centreIntensity == maxIntensity);
       boolean rightMax = (rightIntensity == maxIntensity);

       // Logic for finding the second and third highest light intensities
       if (!leftMax && leftIntensity > secondMaxIntensity)
       {
           secondMaxIntensity = leftIntensity;
       }
       if (!centreMax && centreIntensity > secondMaxIntensity)
       {
           secondMaxIntensity = centreIntensity;
       }
       if (!rightMax && rightIntensity > secondMaxIntensity)
       {
           secondMaxIntensity = rightIntensity;
       }

       // Removes obstructed direction from options to choose from
       if (obstructedDirection != null)
       {
           if (obstructedDirection.equals("left"))
           {
               leftMax = false;
           }
           else if (obstructedDirection.equals("centre"))
           {
               centreMax = false;
           }
           else if (obstructedDirection.equals("right"))
           {
               rightMax = false;
           }

           obstructedDirection = null;
       }

       // Return a direction
       if (leftMax)
       {
           return "left";
       }
       if (centreMax)
       {
           return "centre";
       }
       if (rightMax)
       {
           return "right";
       }

       // Logic for choosing a second best option if a direction is obstructed
       boolean leftSecond = (leftIntensity == secondMaxIntensity);
       boolean centreSecond = (centreIntensity == secondMaxIntensity);
       boolean rightSecond = (rightIntensity == secondMaxIntensity);

       ArrayList<String> secondBestOptions = new ArrayList<>();
       if (leftSecond)
       {
           secondBestOptions.add("left");
       }
       if (centreSecond)
       {
           secondBestOptions.add("centre");
       }
       if (rightSecond)
       {
           secondBestOptions.add("right");
       }
       
       return secondBestOptions.get(random.nextInt(secondBestOptions.size()));
   }


	
   public static void displayMiddle(double leftIntensity, double centreIntensity, double rightIntensity, String movementDirection, int swiftBotSpeed)
   {
       System.out.println("Light intensity readings: ");
       System.out.println("    The light intensity for the left column is " + leftIntensity +".");
       System.out.println("    The light intensity for the centre column is " + centreIntensity +".");
       System.out.println("    The light intensity for the right column is " + rightIntensity +".");
       System.out.println();
      
       System.out.println("The SwiftBot will attempt to move: " + movementDirection +".");
       System.out.println("The SwiftBot is moving at a velocity of " + swiftBotSpeed +".");
       System.out.println();

   }
   
   public static void displayObstacleWarning(double objectDistance)
   {
       try
       {
        
           System.out.println("Objected detected " + objectDistance + "cm ahead.");
           System.out.println();
       
    	   int[] red = {255, 0, 0};
    	   for (int i = 0; i < 5; i++) {
    		    swiftBot.fillUnderlights(red);
    		    Thread.sleep(100);
    		    swiftBot.disableUnderlights();
    		    Thread.sleep(100);
    		}
           
           for (int i = 10; i > 0; i--)
           {
               System.out.println("You have " + i + " seconds to remove the object in the way.");
               Thread.sleep(1000);
               System.out.println();
           }
           System.out.println("Time's up. Please ensure the obstacle is removed.");
       }
       catch (InterruptedException e)
       {
           System.out.println("Error: An error occurred while displaying the obstacle warning.");
           e.printStackTrace();
           System.exit(5);
       }
   }
	
   public static void swiftBotMovement(String movementDirection)
   {
       try 
       {
           int[] green = {0, 255, 0}; 
           swiftBot.fillUnderlights(green);

           if (movementDirection.equals("left"))
           {
        	   System.out.println("Rotating 30 degrees left...");
               swiftBot.move(-55, 55, 400);  
               movementHistory.add("Turn left 30 degrees");

               System.out.println("Moving straight at low speed...");
               swiftBot.move(swiftBotSpeed, swiftBotSpeed, 1000);  
               movementHistory.add("Straight 10cm");

               totalDistance += 10;
               System.out.println();
           }
           else if (movementDirection.equals("centre"))
           {
        	   System.out.println("Moving straight at low speed...");
               swiftBot.move(swiftBotSpeed, swiftBotSpeed, 1000);  
               movementHistory.add("Straight 10cm");

               totalDistance += 10;
               System.out.println();
           }
           else if (movementDirection.equals("right"))
           {
        	   System.out.println("Rotating 30 degrees right...");
               swiftBot.move(55, -55, 350);  
               movementHistory.add("Turn right 30 degrees");

               System.out.println("Moving straight at low speed...");
               swiftBot.move(swiftBotSpeed, swiftBotSpeed, 1000);  
               movementHistory.add("Straight 10cm");

               totalDistance += 10;
               System.out.println();
           }
       }
       catch (Exception e)
       {
           System.out.println("Error: An error occured whilst executing movement.");
           e.printStackTrace();
       }
   }
  
   public static void swiftBotWander()
   {
	   
	   System.out.println("No significant light change detected...");
       Random rand = new Random();
       int randNum = rand.nextInt(360) + 1; 
       System.out.println();

       System.out.println("Entering wandering mode...");
       try
       {
           int leftWheelVelocity = rand.nextBoolean() ? swiftBotSpeed : -swiftBotSpeed;
           int rightWheelVelocity = -leftWheelVelocity;
  
           
           if (leftWheelVelocity > 0) {
               movementHistory.add("Turn left " + randNum + " degrees");
           } else {
               movementHistory.add("Turn right " + randNum + " degrees");
           }
           
           System.out.println("Turning in random direction for 1 second...");
           swiftBot.move(leftWheelVelocity, rightWheelVelocity, randNum);

           System.out.println("Moving in random direction...");
           swiftBot.move(swiftBotSpeed, swiftBotSpeed, 500);
           movementHistory.add("Straight ~5cm");
   
           
           totalDistance += 5;
           System.out.println("Resuming light-seeking...");
           System.out.println();
       }
       catch (Exception e)
       {
           System.out.println("Error: SwiftBot was unable to execute wandering.");
           e.printStackTrace();
       }
   }
	
   public static void displayFinishingQuestion()
   {
	   endReached = true;
       System.out.println("Would you like to display execution logs?");
       System.out.println("Press Button Y for Yes.");
       System.out.println("Press Button X for No.");
       
   }

   public static void displayFinalReport()
   {
       endTime = System.currentTimeMillis();

       long durationMillis = endTime - startTime;
       long durationSeconds = durationMillis / 1000; 

       System.out.println("-Initial light intensity (threshold): " + lightThreshold);
       System.out.println("-Brightest light source detected: " + highestLightIntensity);
       System.out.println("-Direction of the highest light source: " + highestLightDirection);
       System.out.println("Duration of execution: " + durationSeconds + " seconds");
       System.out.println("Total distance traveled: " + totalDistance + "cm");

       String saveDirectory = System.getProperty("user.dir"); 
       System.out.println("-Images saved at: " + saveDirectory);
       
       endReached = false;
       longReportDataReached = true;
       
       try 
       {
    	    System.out.println("Writing log data to file...");

    	    File logFile = new File("swiftbot_log.txt");
    	    FileWriter writer = new FileWriter(logFile); 

    	    writer.write("Initial light intensity: " + lightThreshold + "\n");
    	    writer.write("Highest light intensity detected: " + highestLightIntensity + "\n");
    	    writer.write("Direction of the highest light source: " + highestLightDirection + "\n");
    	    writer.write("Duration of the program's runtime: " + durationSeconds + " seconds\n");
    	    writer.write("Approximate distance covered by SwiftBot: " + totalDistance + "cm\n\n");

    	    writer.write("Light Intensity Records:\n");
    	    for (double[] record : lightIntensityRecords) {
    	        writer.write("Detection #" + (int) record[0] + " -> Left: " + record[1] + ", Centre: " + record[2] + ", Right: " + record[3] + "\n");
    	    }

    	    writer.write("\nSwiftBot Movement History:\n");
    	    for (String move : movementHistory) {
    	        writer.write(move + "\n");
    	    }

    	    writer.write("\nSaved Images:\n");
    	    for (String everyImage : savedImageList) {
    	        writer.write(everyImage + "\n");
    	    }

    	    writer.close(); 
    	    
    	    System.out.println("Log saved successfully.");
    	    System.out.println();
    	} catch (IOException e) {
    	    System.out.println("Error: Failure writing to log file.");
    	    e.printStackTrace();
    	}
       
       System.out.println("Would you like to see the light intensity records, movement history and every saved image?");
       System.out.println("Press Button Y for Yes.");
       System.out.println("Press Button X for No.");
       System.out.println();

   }

}

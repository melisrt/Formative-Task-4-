import swiftbot.*;

public class CalibrationTest {
	static SwiftBotAPI swiftbot; 

	public static void main(String[] args) throws InterruptedException {
		try {
			swiftbot = new SwiftBotAPI();
		} catch (Exception e) {
			/*
			 * Outputs a warning if I2C is disabled. This only needs to be turned on once,
			 * so you won't need to worry about this problem again!
			 */
			System.out.println("\nI2C disabled!");
			System.out.println("Run the following command:");
			System.out.println("sudo raspi-config nonint do_i2c 0\n");
			System.exit(5);
		}
		 lowInitial(); 
	}
	public static void testBotWheels () {
		// swiftbot.move(100, 100, 5000);
		// swiftbot.move(100, 90, 5000);
		// swiftbot.move(100, 85, 5000);      
		// swiftbot.move(100, 88, 5000);  
		//swiftbot.move(100, 88, 5000) 26cm/s max initial speed
	}
	public static void lowInitial() {
		//  swiftbot.move(35, 40, 5000); 19cm/s
	}
}
public class allLights {
public static int totalLights = 0; 
public static int RedNo = 0;
public static int GreenNo = 0;
public static int BlueNo = 0;
public static String MostFrequentCol = ""; 
public static int NumOfMostFrequent = 0; 

	public static void Red() {
		long Redstart = System.currentTimeMillis(); 
		int[] R = { 255, 0, 0 };
		MainFlow.swiftbot.fillUnderlights(R);
		try {
			Thread.sleep(700);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.stopMove();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.startMove(35, 40);
	
		RedNo++;
		
		totalLights = RedNo + BlueNo + GreenNo; 
		
		if (RedNo > BlueNo && RedNo > GreenNo) {
			MostFrequentCol = "Red";
			NumOfMostFrequent = RedNo; 
		}
		long EndRed = System.currentTimeMillis();
		double totalRed = (EndRed - Redstart) / 1000.0;
		MainFlow.totalTime += totalRed; 
	}

	public static void green() {
		long greenStart = System.currentTimeMillis(); 
		int[] G = { 0, 255, 0 };
		MainFlow.swiftbot.fillUnderlights(G);
		MainFlow.swiftbot.move(100, 88, 2000);
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.stopMove();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int[] Y = { 255, 255, 0 };
		MainFlow.swiftbot.fillUnderlights(Y);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.startMove(35, 40);
		
		GreenNo++;
		
		totalLights = RedNo + BlueNo + GreenNo; 
		
		if (GreenNo > BlueNo && GreenNo > RedNo) {
			MostFrequentCol = "Green";
			NumOfMostFrequent = GreenNo; 
		}
		long endGreen = System.currentTimeMillis();
		double totalGreen = (endGreen - greenStart) / 1000.0;
		MainFlow.totalTime += totalGreen; 
	}

	public static void blue() {
		long blueStart = System.currentTimeMillis();
		MainFlow.swiftbot.stopMove();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int[] B = { 0, 0, 255 };
		int[] off = { 0, 0, 0 };
		for (int i = 0; i <= 10; i++) {
			MainFlow.swiftbot.fillUnderlights(B);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			MainFlow.swiftbot.fillUnderlights(off);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		MainFlow.swiftbot.move(0, 40, 1350); 
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.move(30, 40, 1000);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.move(-30, -40, 1000);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MainFlow.swiftbot.move(0, -40, 1350);
		for (int i = 0; i <= 10; i++) {
			MainFlow.swiftbot.fillUnderlights(B);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			MainFlow.swiftbot.fillUnderlights(off);
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		MainFlow.swiftbot.startMove(35, 40);
		
		BlueNo++;
		
		totalLights = RedNo + BlueNo + GreenNo; 
		
		if (BlueNo > RedNo && BlueNo > GreenNo) {
			MostFrequentCol = "Blue";
			NumOfMostFrequent = BlueNo; 
		}
		long endBlue = System.currentTimeMillis();
		double totalBlue = (endBlue - blueStart) / 1000.0;
		MainFlow.totalTime += totalBlue;
	}
}

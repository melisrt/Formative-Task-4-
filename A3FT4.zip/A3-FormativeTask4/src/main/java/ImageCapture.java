import swiftbot.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageCapture {
	public static void getImage() {
		try {
			BufferedImage img = MainFlow.swiftbot.takeStill(ImageSize.SQUARE_48x48);
			ImageIO.write(img, "jpg", new File("/data/home/pi/Documents/ColouredImage.jpg"));
			try {
				Thread.sleep(1000); 
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void getRGB() {
		long startCamera = System.currentTimeMillis();
		double distance = 0;
		for (int i = 0; i <= 1000; ++i) {
			distance = MainFlow.swiftbot.useUltrasound();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (distance <= 30) {
				getImage();
			String fn = "/data/home/pi/Documents/ColouredImage.jpg";
			try {
				BufferedImage img = ImageIO.read(new File(fn));

				myBreakLabel: for (int x = 0; x < img.getWidth(); ++x) {
					for (int y = 0; y < img.getHeight(); ++y) {
						int p = img.getRGB(y, x);
						int r = (p >> 16) & 0xFF;
						int g = (p >> 8) & 0xFF;
						int b = p & 0xFF;
						if (r > b && r > g) {
							System.out.println("Red");
							System.out.println("Distance: " + distance);
							allLights.Red(); 
							break myBreakLabel;
						} else if (g > b && g > r) {
							System.out.println("Green");
							System.out.println("Distance: " + distance);
							allLights.green();
							break myBreakLabel;
						} else if (b > g & b > r) {
							System.out.println("Blue");
							System.out.println("Distance: " + distance);
							allLights.blue();
							break myBreakLabel;
						} else if (p != r || p != b || p != g) {
							MainFlow.swiftbot.stopMove();
							System.out.println("Object within 30cm, please remove the object");
							break myBreakLabel;
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println();
		} 
		if (distance > 30) {
			MainFlow.swiftbot.startMove(35, 40);
			int[] Yellow = { 255, 255, 0 };
			MainFlow.swiftbot.fillUnderlights(Yellow);
		} else
			;

	}
		long endCamera = System.currentTimeMillis();
		double totalCamera = (endCamera - startCamera) / 1000.0;
		MainFlow.totalTime += totalCamera; 
}
}

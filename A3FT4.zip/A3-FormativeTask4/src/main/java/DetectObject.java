import swiftbot.SwiftBotAPI;
import swiftbot.Button;
import swiftbot.ImageSize;

import java.awt.image.BufferedImage;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;

public class DetectObject {
    static SwiftBotAPI API = new SwiftBotAPI();
    static String selectedMode = "";
    static boolean stopCurrentLoop = false;
    static boolean logDisplayed = false;
    static int objectEncounterCount = 0;
    static LocalTime startTime;
    static LocalTime endTime;
    static final String LOG_FILE_PATH = "swiftbot_execution_log.txt";
    static final String IMAGE_SAVE_PREFIX = "Object_";
    static Random random = new Random();

    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);

    	//Introduction UI
    	System.out.println("==================================================");
    	System.out.println("  Welcome to Detect an Object with your SwiftBot! ");
    	System.out.println("==================================================");
    	System.out.println(" ");
    	System.out.println("     This program controls SwiftBot behavior.");
    	System.out.println("     Please scan a QR code to select a mode.");
    	System.out.println(" ");
    	System.out.println("==================================================");

    	setupButtonListeners(); //Sets up button listeners for stopping execution and viewing logs

    	boolean continueRunning = true;

    	while (continueRunning) {
    		resetState(); //Resets execution state before scanning QR code

    		System.out.println("==================================================");
    		System.out.println(" ");
    		System.out.println("      Scanning QR Code to select mode...");
    		System.out.println(" ");
    		System.out.println("==================================================");
    		getQRcodeInput(); //Reads QR code input to determine mode

    		if (!determineModeFromQR()) { //Decodes QR code and selects mode

    			System.out.println("Mode Selected: " + selectedMode);
    		}

    		displayModeUI(); //Displays mode-specific UI after selection

    		try {
    			executeModeBehavior(); //Executes the corresponding behaviour based on mode
    		} catch (InterruptedException e) {
    			System.err.println("Execution interrupted.");
    			Thread.currentThread().interrupt();
    		}

    		endTime = LocalTime.now();
    		logExecutionDetails();

    		System.out.println("Would you like to scan a new QR code? (yes/no)");
    		String input = scanner.nextLine().trim().toLowerCase();

    		if (!input.equals("yes")) {
    			System.out.println("Shutting down. Goodbye!");
    			continueRunning = false;
    		}

    	}

    	scanner.close();
    	API.stopMove();
    	API.disableUnderlights();
    	System.exit(0);
    }

    private static void resetState() {
    	selectedMode = "";
    	stopCurrentLoop = false;
    	logDisplayed = false;
    	objectEncounterCount = 0;
    	startTime = LocalTime.now();
    	endTime = null;
    }

    private static void setupButtonListeners() {
    	Scanner scanner = new Scanner(System.in);
    	API.disableButton(Button.X);
    	API.disableButton(Button.Y);

    	API.enableButton(Button.X, () -> { //Stops execution when 'X' is pressed
    		System.out.println("[X] button pressed - Stopping current mode...");
    		stopCurrentLoop = true;
    		API.stopMove();
    		API.disableUnderlights();
    	});

    	API.enableButton(Button.Y, () -> { //Displays log when 'Y' is pressed
    		
    		stopCurrentLoop = true;
    		API.stopMove();
    		API.disableUnderlights();
    		
    		if (!logDisplayed) {
    			
    			//Terminating the program
    			System.out.println("==================================================");
    			System.out.println("             EXECUTION COMPLETED  ");
    			System.out.println("==================================================");
    			System.out.println(" ");
    			System.out.println("  Would you like to view the execution log? (yes/no)");
    			String input = scanner.nextLine().trim().toLowerCase();

    			if (input.equals("yes")) {
    				displayLog(); //Execution Log UI
    			} else {
    				displayFileLog(); //Displaying the File Log only
    			}
    			logDisplayed = true;
    		}
    	});
    }


    private static void getQRcodeInput() {  //Scans and decodes QR code input
        String QRCode = "";
        long start = System.currentTimeMillis();

        while (QRCode.isEmpty() && !stopCurrentLoop) {
            BufferedImage QR = API.getQRImage();
            if (QR != null) {
                QRCode = API.decodeQRImage(QR);
                if (QRCode != null && !QRCode.trim().isEmpty()) {
                    selectedMode = QRCode.trim();
                    System.out.println("Decoded QR code: " + selectedMode);
                    return;
                }
            }
            if (System.currentTimeMillis() - start > 10000) {
                System.err.println("No QR code detected in 10 seconds :( Try again.");
                start = System.currentTimeMillis();
            }
        }
    }

    private static boolean determineModeFromQR() { //Determines mode based on QR input
        switch (selectedMode) {
            case "1001":
                selectedMode = "Curious SwiftBot";
                break;
            case "2002":
                selectedMode = "Scaredy SwiftBot";
                break;
            case "3003":
                String chosenMode = random.nextBoolean() ? "Curious SwiftBot" : "Scaredy SwiftBot";
                System.out.println("Dubious selected mode: " + chosenMode);
                selectedMode = "Dubious Mode"; 
                break;
            default:
            	//Invalid QR Code UI
            	System.err.println("==================================================");
            	System.err.println("          INVALID QR CODE DETECTED  ");
            	System.err.println("==================================================");
            	System.err.println(" ");
            	System.err.println("        QR Code not recognized :(  ");
            	System.err.println("        Please scan one of the following:");
            	System.err.println("        - 1001 for Curious SwiftBot");
            	System.err.println("        - 2002 for Scaredy SwiftBot");
            	System.err.println("        - 3003 for Dubious Mode");
            	System.err.println(" ");
            	System.err.println("==================================================");
                selectedMode = "";
                return false;
        }

        API.fillUnderlights(new int[]{0, 0, 255});  //Sets underlights to blue for wandering
        return true;
    }
    
    private static void displayModeUI() {
        System.out.println("==================================================");
        System.out.println(" ");
        System.out.println("               MODE SELECTED:");
        System.out.println(" ");
        System.out.println("==================================================");
        System.out.println(" ");
        System.out.println("             " + selectedMode);
        System.out.println(" ");
        System.out.println("==================================================");

        if (selectedMode.equals("Curious SwiftBot")) {
            System.out.println("  CURIOUS SWIFTBOT MODE  ");
            System.out.println("---------------------------------");
            System.out.println(" ");
            System.out.println(" -> Exploring surroundings...");
            System.out.println(" -> Capturing objects...");
            System.out.println(" -> Blue lights for wandering...");
            System.out.println(" ");
            System.out.println("---------------------------------");
        } else if (selectedMode.equals("Scaredy SwiftBot")) {
            System.out.println("  SCAREDY SWIFTBOT MODE  ");
            System.out.println("---------------------------------");
            System.out.println(" ");
            System.out.println(" -> Avoiding objects...");
            System.out.println(" -> Moving away on detection...");
            System.out.println(" -> Red lights when scared...");
            System.out.println(" ");
            System.out.println("---------------------------------");
        } else if (selectedMode.equals("Dubious Mode")) {
            System.out.println("  DUBIOUS MODE  ");
            System.out.println("---------------------------------");
            System.out.println(" ");
            System.out.println(" -> Indecisive behavior...");
            System.out.println(" -> Choosing between modes...");
            System.out.println(" -> Yellow lights of confusion...");
            System.out.println(" ");
            System.out.println("---------------------------------");
        }

        System.out.println("Mode is now active :) Beginning execution...");
    }
    
    
    private static void executeModeBehavior() throws InterruptedException {
        while (!stopCurrentLoop) {
            double distance = API.useUltrasound(); //Uses the sensor to detect objects

            if (selectedMode.equals("Curious SwiftBot")) { //Implements 'Curious SwiftBot' behaviour
                if (distance > 30) {
                    API.fillUnderlights(new int[]{0, 255, 0});
                    API.startMove(40, 40);
                } else if (distance < 30) {
                    API.fillUnderlights(new int[]{0, 255, 0});
                    API.startMove(-40, -40);
                } else {
                    API.stopMove();
                    blinkUnderlights(new int[]{0, 255, 0}, 3, 400);
                    captureImage();
                    Thread.sleep(5000);
                }
            }

            else if (selectedMode.equals("Scaredy SwiftBot")) { //Implements 'Scaredy SwiftBot' behaviour
                if (distance < 50) {
                    objectEncounterCount++;
                    API.fillUnderlights(new int[]{255, 0, 0});
                    captureImage();
                    blinkUnderlights(new int[]{255, 0, 0}, 3, 300);
                    API.move(-50, -50, 1000);
                    API.move(50, -50, 1500);
                    API.move(50, 50, 3000);
                } else {
                    API.fillUnderlights(new int[]{0, 0, 255});
                    API.startMove(40, 40);
                }
            }
            
            else if (selectedMode.equals("Dubious Mode")) {
            	API.fillUnderlights(new int[]{255, 165, 0});
            	API.startMove(random.nextBoolean() ? 40 : -40, random.nextBoolean() ? 40 : -40);
            	Thread.sleep(random.nextInt(3000) + 1000);
            }

            Thread.sleep(1000);
        }

        API.stopMove();
        API.disableUnderlights();
    }

    private static void blinkUnderlights(int[] rgb, int times, int delayMs) throws InterruptedException {
        for (int i = 0; i < times; i++) {
            API.fillUnderlights(rgb);
            Thread.sleep(delayMs);
            API.disableUnderlights();
            Thread.sleep(delayMs);
        }
    }

    private static void captureImage() { //Captures an image when an object is detected
        BufferedImage image = API.takeStill(ImageSize.SQUARE_720x720);
        if (image != null) {
            String filename = IMAGE_SAVE_PREFIX + LocalTime.now().format(DateTimeFormatter.ofPattern("HHmmss")) + ".png";
            System.out.println("Image saved: " + filename);
            objectEncounterCount++;
        } else {
            System.err.println("Failed to capture image.");
        }
    }

    private static void logExecutionDetails() { //Logs execution details after completion
        endTime = (endTime == null) ? LocalTime.now() : endTime;
        long duration = Duration.between(startTime, endTime).getSeconds();

        try (FileWriter writer = new FileWriter(LOG_FILE_PATH)) {
            String log = "SwiftBot Execution Log:"
                    + "Mode: " + selectedMode + " "
                    + "Duration: " + duration + " seconds "
                    + "Object Encounters: " + objectEncounterCount + "  "
                    + "Log File: " + LOG_FILE_PATH + "  ";
            writer.write(log);
        } catch (IOException e) {
            System.err.println("Failed to write log: " + e.getMessage());
        }
    }
    
    private static void displayLog() {
        long duration = Duration.between(startTime, endTime).getSeconds();
        System.out.println("==================================================");
        System.out.println("                 EXECUTION LOG  ");
        System.out.println("==================================================");
        System.out.println(" Mode: " + selectedMode);
        System.out.println(" Duration: " + duration + " seconds");
        System.out.println(" Object Encounters: " + objectEncounterCount);
        System.out.println(" Log File: " + LOG_FILE_PATH);
        System.out.println("==================================================");
    }

    private static void displayFileLog() {
        System.out.println("==================================================");
        System.out.println("               LOG FILE DETAILS  ");
        System.out.println("==================================================");
        System.out.println(" Execution details saved to:");
        System.out.println(LOG_FILE_PATH);
        System.out.println("==================================================");
    }
}
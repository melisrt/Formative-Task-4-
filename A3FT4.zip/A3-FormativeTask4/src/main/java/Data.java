

import swiftbot.*;
import java.awt.image.BufferedImage;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Data{
  static SwiftBotAPI swiftBot;
  static Scanner scanner = new Scanner(System.in);
  static List<String> shapeLog = new ArrayList<>();
  static double totalDrawTime = 0;
  static int totalDraws = 0;
  static Map<String, Integer> shapeCount = new HashMap<>();
//  static Scanner scanner1 = new Scanner(System.in);
  static boolean isRunning = true; // Flag to control execution
  
  
  public static void Exit() {
	  isRunning = false; // Stop program execution
	  System.exit(0);
  }
 
  public static void main(String[] args) throws InterruptedException {
      System.out.println("\n*****************************************************************");
      System.out.println("*****************************************************************");
      System.out.println("\t\tSwiftbot Draw Shapes by Usman Khan");
      System.out.println("*****************************************************************");
      System.out.println("*****************************************************************\n");

      try {
          swiftBot = new SwiftBotAPI();
          
          // Enable X button 
             swiftBot.enableButton(Button.X, () -> {
                 System.out.println("X Button has been Pressed.Program terminated by user.\n Exiting program and logging shape Data...");
                 writeLog(); // save Log 
                
                 Exit();
                 
             });
      } catch (Exception e) {
          System.out.println("SwiftBot setup failed. Exiting...");
          System.exit(0);
      }

   

      
      while (true) {
          System.out.println("Scanning for a QR code...");
          String qrCode = scanQRCode();

          if (qrCode.isEmpty()) {
              System.out.println("No QR code detected. Retrying.....");
              continue;
          }

          System.out.println(" The QR Code scanned contains: " + qrCode);
          try {
        	  inputCheck(qrCode);
          } catch(Exception e) {
        	  System.out.println("invalid input.Please scan another QR code");
        	  qrCode = "";
        	  scanQRCode();
        	  
          }
      }
  }

//Function to scan a QR code
public static String scanQRCode() {
   long startTime = System.currentTimeMillis();
   long endTime = startTime + 10000;

   System.out.println("Starting 10s timer to scan a QR code....");
   try {
       while (System.currentTimeMillis() < endTime) {
           BufferedImage img = swiftBot.getQRImage();
           if (img == null) {
               System.out.println("Camera returned a null image. Retrying...");
               Thread.sleep(1000);
               continue;
           }

           String decodedMessage = swiftBot.decodeQRImage(img);
           if (!decodedMessage.isEmpty()) {
               System.out.println("QR code detected: " + decodedMessage);
               return decodedMessage;
           }
           
           if (isRunning) {
               System.out.println("No QR code detected. Please adjust the distance and try again.");
               Thread.sleep(1000);
           } else {
               System.exit(0);
           }
       }
   } catch (Exception e) {
       System.out.println("Unable to scan QR code. Please try again!");
   }

   return "";
}


  //  Method to Process multiple Shapes
  public static void inputCheck(String qrCode) throws InterruptedException {
	    String[] shapes = qrCode.split("&");

	    // check for multiple && symbols
	    for (int i = 0; i < shapes.length - 1; i++) {
	        if (shapes[i].isEmpty() && shapes[i + 1].isEmpty()) {
	            System.out.println("Invalid input!Please try again");
	            return;
	        }
	    }

	    if (shapes.length > 5) {
	        System.out.println("Invalid input!Maximum 5 shapes allowed per QR code.");
	        return;
	    }

	    for (int i = 0; i < shapes.length; i++) {
	        if (i > 0) { // Move back before drawing multiple shapes
	            swiftBot.move(-49, -59, 1500); 
	        }
	        System.out.println(shapes[i]);
	        processShape(shapes[i]);
	    }
	}



//Process a Shape
public static void processShape(String shapeData) throws InterruptedException {
   String[] parts = shapeData.split("-");

   int shapeTime = 0; // Store drawing time
   long startTime = System.currentTimeMillis(); // Start time before drawing
   char shapeType = parts[0].charAt(0); // extract shape type here

   if (parts.length == 2) {
       if (shapeType == 'S' || shapeType == 's') {
           int sideLength = Integer.parseInt(parts[1].trim());
           if (sideLength >= 15 && sideLength <= 85) {
               shapeTime = sideLength * 55; // time taken for drawing a shape
               drawSquare(sideLength);
               shapeLog.add("Square: " + sideLength);
               shapeCount.put("Square", shapeCount.getOrDefault("Square", 0) + 1);
           } else {
               System.out.println("Invalid square size in input!Please scan another QR Code");
           }
       }
   } else if (parts.length == 3) {
       if (shapeType == 'R' || shapeType == 'r') {
           int sideLength1 = Integer.parseInt(parts[1].trim());
           int sideLength2 = Integer.parseInt(parts[2].trim());
           if (sideLength1 >= 15 && sideLength1 <= 85 && sideLength2 >= 15 && sideLength2 <= 85) {
               shapeTime = (sideLength1 + sideLength2) * 55;
               drawRectangle(sideLength1, sideLength2);
               shapeLog.add("Rectangle: " + sideLength1 + " x " + sideLength2);
               shapeCount.put("Rectangle", shapeCount.getOrDefault("Rectangle", 0) + 1);
           } else {
               System.out.println("Invalid rectangle size in input!Please scan another QR Code");
           }
       }
   } else if (parts.length == 4) {
       if (shapeType == 'T' || shapeType == 't') {
           int a = Integer.parseInt(parts[1].trim());
           int b = Integer.parseInt(parts[2].trim());
           int c = Integer.parseInt(parts[3].trim());

           if (isTriangle(a, b, c)) {
               shapeTime = (a + b + c) * 55; // Estimate 
               drawTriangle(a, b, c);
//               shapeLog.add("Triangle: " + a + ", " + b + ", " + c);
               shapeCount.put("Triangle", shapeCount.getOrDefault("Triangle", 0) + 1);
           } else {
               System.out.println("Invalid input for a triangle!Please scan another QR Code");
           }
       }
   }

// Calculate time taken for this shape
long endTime = System.currentTimeMillis();
long timeTaken = endTime - startTime; // measured in milliseconds

// updating time and count
if (shapeTime > 0) {
    // Use the actual measured time converted to seconds (using floating point division)
    totalDrawTime += (double) timeTaken / 1000;
    totalDraws++;

    // Log the measured time in seconds
    shapeLog.add("Time taken to draw this shape: " + ((double) timeTaken / 1000) + " seconds");
}

}



  //  Check if Valid Triangle
  public static boolean isTriangle(int a, int b, int c) {
  	if((a<=15||a>=85)&&(b<=15||b>=85)&&(c<=15||c>=85)) {
          System.out.println("Invalid triangle size! Must be between 15 and 85.");
          return false;
  	}
      return (a + b > c) && (a + c > b) && (b + c > a);
  }

  //  Draw Square
  public static void drawSquare(int sideLength) throws InterruptedException {
  	underrlights();
  	System.out.println("Drawing a square with side length: " + sideLength);
      int shapeTime = sideLength * 55; 

      for (int i = 0; i < 4; i++) {
          swiftBot.move(49, 59, shapeTime);
          turnRight(90);
      }
      blinkUnderlights();
  }
//draw triangle
  public static void drawTriangle(int sideA, int sideB, int sideC) throws InterruptedException {
	  	underrlights();
	  	System.out.println("Drawing a triangle with sides: " + sideA + ", " + sideB + ", " + sideC);
	      int angleA = calculateAngle(sideA, sideB, sideC);
	      int angleB = calculateAngle(sideB, sideA, sideC);
	      int angleC = 180 - angleA - angleB;

	      shapeLog.add(String.format("Triangle: Sides: %d, %d, %d | Angles: %d, %d, %d", sideA, sideB, sideC, angleA, angleB, angleC));

	      int tTimeA = sideA * 55; 
	      int tTimeB = sideB * 55; 
	      int tTimeC = sideC * 55; 
	      
	      
	          swiftBot.move(49, 59, tTimeA);
	          turnRight((180-angleA));
	          swiftBot.move(49, 59, tTimeB);
	          turnRight((180-angleB));
	          swiftBot.move(49, 59, tTimeC);
	          turnRight((180-angleC));
	          
	          
	          
	      blinkUnderlights();
	      
	  }

  // Blink green lights after drawing a shape
  public static void blinkUnderlights() throws InterruptedException {
      int[] green = {0, 255, 0};
      swiftBot.fillUnderlights(green);
      Thread.sleep(500);
      swiftBot.disableUnderlights();
  }

  // Log Shape Data

public static void writeLog() {
   try (FileWriter writer = new FileWriter("Shapedrawing_log.txt")) {
       writer.write("Drawing Log:\n");

       // log each shape drawn
       for (String shape : shapeLog) {
           writer.write(shape + "\n");
       }

       // find largest shape by area
       String Largestshape = shapeLog.stream()
           .max(Comparator.comparingInt(Data::calculateShapeArea))
           .orElse("No shapes drawn");
       writer.write("\nLargest Shape: " + Largestshape + "\n");

       // find shape drawn most frequently 
       String mostFrequentShape = shapeCount.entrySet().stream()
           .max(Map.Entry.comparingByValue())
           .map(entry -> entry.getKey() + ": " + entry.getValue() + " times")
           .orElse("No shapes drawn");
       writer.write("Most Drawn Shape: " + mostFrequentShape + "\n");

       // Calculate average draw time
       double averageTime = (totalDraws > 0) ? (totalDrawTime / totalDraws) : 0;
       writer.write("Average Drawing Time: " + averageTime + " seconds\n");

       System.out.println("log saved to: drawing_log.txt");

   } catch (IOException e) {
       System.out.println("Error writing log file: " + e.getMessage());
   }
}

// calculate Shape area for logging
private static int calculateShapeArea(String shapeLogEntry) {
   String[] parts = shapeLogEntry.split(":|\\(|,|\\)");
   try {
       if (shapeLogEntry.startsWith("Square")) {
           int side = Integer.parseInt(parts[1].trim());
           return side * side; // Area of square = sideÃ‚Â²
       } else if (shapeLogEntry.startsWith("Triangle")) {
           int a = Integer.parseInt(parts[1].trim());
           int b = Integer.parseInt(parts[2].trim());
           int c = Integer.parseInt(parts[3].trim());
           double s = (a + b + c) / 2.0;
           return (int) Math.sqrt(s * (s - a) * (s - b) * (s - c)); // formula to calculate triangle area
       }
   } catch (Exception ignored) {
   }
   return 0; // the default if parsing fails
}


  
//  method to turn right
  public static void turnRight(int angle) throws InterruptedException {
      
  	int speed = 59;
      int duration = angle * 6; 
      swiftBot.move(speed, -speed, duration);
      Thread.sleep(duration);
  }
  
  

public static void underrlights() throws InterruptedException {
	

	
	
	int[] shapeLights = new int[] { 255, 255, 255 };
	
	try {
		// Declaring an array of under lights.
		Underlight[] underlights = new Underlight[] { Underlight.BACK_LEFT, Underlight.BACK_RIGHT,
				Underlight.MIDDLE_LEFT,
				Underlight.MIDDLE_RIGHT, Underlight.FRONT_LEFT, Underlight.FRONT_RIGHT };

		for (Underlight underlight : underlights) { 
			swiftBot.setUnderlight(underlight, shapeLights);
//			
			Thread.sleep(200);

			
		}
	} catch (Exception e) {
		
		System.out.println("ERROR: Unable to set under light");
		System.exit(5);
	}

	Thread.sleep(2000);
	
}
public static void drawRectangle(int sideLength1, int sideLength2) throws InterruptedException {
  System.out.println("Drawing a Rectangle with side length: " + sideLength1 + "-" + sideLength2);
  int shapeTimeOne = sideLength1 * 55; 
  int shapeTimeTwo = sideLength2 * 55;
  underrlights();
      swiftBot.move(49, 59, shapeTimeOne);
      turnRight(90);
      swiftBot.move(49, 59, shapeTimeTwo);
      turnRight(90);
      swiftBot.move(49, 59, shapeTimeOne);
      turnRight(90);
      swiftBot.move(49, 59, shapeTimeTwo);
      turnRight(90);
      blinkUnderlights();
     
}
public static int calculateAngle(int a, int b, int c) {
    double aa=Math.acos((Math.pow(a, 2) + Math.pow(b, 2) - Math.pow(c, 2)) / (2.0 * a * b)) * (180 / Math.PI);
return (int)aa;

}

}


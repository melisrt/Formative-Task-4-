
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class ColourScanner {
    public static int[] getAverageRGB(String imagePath) {
        try {
            File file = new File(imagePath);
            BufferedImage image = ImageIO.read(file);

            int width = image.getWidth();
            int height = image.getHeight();
            long sumRed = 0, sumGreen = 0, sumBlue = 0;
            int pixelCount = width * height;

            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    int pixel = image.getRGB(x, y);
                    sumRed += (pixel >> 16) & 0xFF;
                    sumGreen += (pixel >> 8) & 0xFF;
                    sumBlue += pixel & 0xFF;
                }
            }

            int avgRed = (int) (sumRed / pixelCount);
            int avgGreen = (int) (sumGreen / pixelCount);
            int avgBlue = (int) (sumBlue / pixelCount);

            return new int[]{avgRed, avgGreen, avgBlue};
        } catch (Exception e) {
            System.err.println(" Error processing image: ");
            return new int[]{0, 0, 0}; // Default black in case of error
        }
    }
}

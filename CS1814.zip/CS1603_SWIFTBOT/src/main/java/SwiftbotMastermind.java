
import java.io.FileWriter;
import swiftbot.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;


import javax.imageio.ImageIO;


public class SwiftbotMastermind {
	
	static SwiftBotAPI swiftBot;
	
	// Encapsulation
    private static final char[] COLOURS = {'R', 'G', 'B', 'Y', 'O', 'P'};
    private static final int DEFAULT_LENGTH = 4;
    private static final int DEFAULT_GUESSES = 6;
    private static int playerScore = 0;
    private static int computerScore = 0;
    private static boolean buttonPressed = false;
    private static Button lastPressedButton;
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws InterruptedException {
        swiftBot = new SwiftBotAPI();
        SwiftbotMastermind game = new SwiftbotMastermind();
        game.setupButtons();
        game.startGame();
    }


    // Abstraction
    public void setupButtons() throws InterruptedException {
    	
    	try {
        System.out.println("Enabling Buttons...");
        
        swiftBot.enableButton(Button.A, () -> {
            System.out.println("Button A Pressed.");
            lastPressedButton = Button.A;
            handleButtonPress(Button.A);
            buttonPressed = true;
        });

        swiftBot.enableButton(Button.B, () -> {
            System.out.println("Button B Pressed.");
            lastPressedButton = Button.B;
            handleButtonPress(Button.B);
            buttonPressed = true;
        });

        swiftBot.enableButton(Button.X, () -> {
            System.out.println("Button X Pressed.");
            lastPressedButton = Button.X;
            handleButtonPress(Button.X);
            buttonPressed = true;
        });

        swiftBot.enableButton(Button.Y, () -> {
            System.out.println("Button Y Pressed.");
            lastPressedButton = Button.Y;
            handleButtonPress(Button.Y);
            buttonPressed = true;
        });

        System.out.println("Buttons successfully enabled.");
        
       
    } catch (Exception e) {
        System.err.println("Failed to enable buttons!");
        e.printStackTrace();
        System.exit(5);
    }}
    
    private synchronized void handleButtonPress(Button button) {
       
            //  Debounce delay to prevent duplicate presses
            try {
                Thread.sleep(500); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            buttonPressed = false;
        }
    
    
    private void startGame() throws InterruptedException {
        boolean playAgain = true;
        int round = 1;

        while (playAgain) {
            System.out.println(" Welcome to SwiftBot Mastermind!");
            System.out.println(" Press 'A' for Default Mode (4 Colours, 6 Guesses).");
            System.out.println(" Press 'B' for Customised Mode.");

            buttonPressed = false; 
            lastPressedButton = null;

            while (!buttonPressed || (lastPressedButton != Button.A && lastPressedButton != Button.B)) {
                Thread.sleep(100); // Prevents CPU overuse

                if (buttonPressed && lastPressedButton != Button.A && lastPressedButton != Button.B) {
                    System.out.println(" Invalid selection! Please press either 'A' or 'B'.");
                    buttonPressed = false; // Reset and wait for valid input
                }
            }
            
            
            int numColours = DEFAULT_LENGTH;
            int maxGuesses = DEFAULT_GUESSES;

            if (lastPressedButton == Button.B) {
            	
                buttonPressed = false;

                numColours = getUserInput(" Enter number of colours (3-6):", 3, 6);
                maxGuesses = getUserInput(" Enter max number of guesses (3-10):", 3, 10);
            }

            // Generate and display the random sequence before the game starts
            String secretCode = generateRandomCode(numColours);
            System.out.println(" A random colour sequence has been generated! ");

            try {
                //  Pass the secret code into the game
                playGame(round, numColours, maxGuesses, secretCode);
            } catch (IOException e) {
                System.out.println(" Error starting the game.");
            }

            playAgain = promptContinue();
            round++;
        }

        System.out.println(" Log file saved at: game_log.txt");
    }


    // Polymorphism
    private int getUserInput(String prompt, int min, int max) {
        System.out.println(prompt);
        int input;

        while (true) {
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
                if (input >= min && input <= max) {
                    break; // Valid input, exit loop
                }
            } else {
                scanner.next(); // Clear invalid input
            }
            System.out.println("Invalid input! Enter a number between " + min + " and " + max + ".");
        }

        return input;
    }


    private void playGame(int round, int numColours, int maxGuesses, String secretCode) throws IOException {
        int lives = maxGuesses;

        while (lives > 0) {
            System.out.println("\n Attempt " + (maxGuesses - lives + 1) + "/" + maxGuesses);

            // Scan once at the start of the loop
            String playerGuess = scanColourCards(numColours, 0);
            
            if (playerGuess.length() != secretCode.length()) {
                System.out.println("Error: Incomplete scan. Please try scanning your colour cards again.");
                continue;  
            }
            
            if (playerGuess.equals(secretCode)) {
                System.out.println(" Congrats on winning! The correct code was: " + secretCode);
                playerScore++;
                break;
            } else {
                lives--;
                String feedback = generateFeedback(secretCode, playerGuess);
                System.out.println(" Feedback: " + feedback);
                System.out.println(" Incorrect! Lives left: " + lives);
            }
        }


        if (lives == 0) {
            System.out.println(" Game Over! The correct code was: " + secretCode);
            computerScore++;
        }

        logGameResult(round, secretCode, null, maxGuesses, lives);
    }
    
    // Abstraction
    private String scanColourCards(int numCards, int imageIndex) throws IOException {
        StringBuilder detectedSequence = new StringBuilder();
        System.out.println("\nLet's scan your " + numCards + " colour cards!");

        for (int i = 1; i <= numCards; i++) {
            System.out.println("\nHold up Colour Card " + i + " in front of the camera.");
            System.out.println("Press Button A when ready...");

            while (true) {
                buttonPressed = false;
                lastPressedButton = null;             

            // Wait until Button A is pressed
                while (!buttonPressed) {
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                if (lastPressedButton == Button.A) {
                    break; // Correct button, proceed with scanning
                } else {
                    System.out.println("Error: Invalid button pressed! Please press 'A' to scan.");
                }
            }

            System.out.println("\nCapturing image...");
            String imagePath = captureAndSaveImage(imageIndex);

            if (imagePath != null && new File(imagePath).exists()) {
                int[] avgRGB = ColourScanner.getAverageRGB(imagePath);
                String detectedColour = getClosestColour(avgRGB[0], avgRGB[1], avgRGB[2]);

                detectedSequence.append(detectedColour);
                System.out.println("Detected Colour for Card " + i + ": " + detectedColour);
            } else {
                System.out.println("Skipping card " + i + " due to failed image capture.");
            }

            // Reset for the next card
            buttonPressed = false;
            lastPressedButton = null;
        }
        return detectedSequence.toString();
    }


    
    private String getClosestColour(int r, int g, int b) {
        Map<String, int[]> colourMap = new HashMap<>();
        colourMap.put("R", new int[]{220, 0, 0});   // Red
        colourMap.put("G", new int[]{0, 220, 0});   // Green
        colourMap.put("B", new int[]{0, 0, 220});   // Blue
        colourMap.put("Y", new int[]{255, 255, 0}); // Yellow
        colourMap.put("O", new int[]{255, 165, 0}); // Orange
        colourMap.put("P", new int[]{255, 0, 255}); // Pink

        double minDistance = Double.MAX_VALUE;
        String closestColour = "?";

        for (Map.Entry<String, int[]> entry : colourMap.entrySet()) {
            int[] colourRGB = entry.getValue();
            
            // Use Euclidean distance for better accuracy
            double distance = Math.sqrt(Math.pow(r - colourRGB[0], 2) + 
                                        Math.pow(g - colourRGB[1], 2) + 
                                        Math.pow(b - colourRGB[2], 2));

            if (distance < minDistance) {
                minDistance = distance;
                closestColour = entry.getKey();
            }
        }

        return closestColour;
    }

    private String captureAndSaveImage(int imageIndex) {
        String filePath = "image" + imageIndex + ".jpg"; // Save with a unique name

        try {
            BufferedImage image = swiftBot.takeStill(ImageSize.SQUARE_720x720); // Capture colour image

            if (image == null) { 
                throw new IOException("Image capture failed.");
            }

            ImageIO.write(image, "jpg", new File(filePath)); // Save image to file
            return filePath;
        } catch (IOException e) {
            System.err.println(" Error capturing image " + imageIndex + ". Please try again.");
            return null;
        }
    }

	private String generateRandomCode(int length) {
        List<Character> colourList = new ArrayList<>();
        for (char c : COLOURS) colourList.add(c);
        Collections.shuffle(colourList);

        StringBuilder code = new StringBuilder();
        for (int i = 0; i < length; i++) code.append(colourList.get(i));
        return code.toString();
    }

    private String generateFeedback(String secret, String guess) {
        int correctPos = 0, correctColour = 0;
        Map<Character, Integer> colourCounts = new HashMap<>();

        for (char c : secret.toCharArray()) colourCounts.put(c, colourCounts.getOrDefault(c, 0) + 1);

        for (int i = 0; i < secret.length(); i++) {
            if (guess.charAt(i) == secret.charAt(i)) {
                correctPos++;
                colourCounts.put(secret.charAt(i), colourCounts.get(secret.charAt(i)) - 1);
            }
        }

        for (int i = 0; i < guess.length(); i++) {
            if (guess.charAt(i) != secret.charAt(i) && colourCounts.getOrDefault(guess.charAt(i), 0) > 0) {
                correctColour++;
                colourCounts.put(guess.charAt(i), colourCounts.get(guess.charAt(i)) - 1);
            }
        }

        return "+".repeat(correctPos) + "-".repeat(correctColour);
    }

    private boolean promptContinue() {
        System.out.println("\nDo you want to play again?");
        System.out.println("Press 'Y' to Continue or 'X' to Exit.");

        buttonPressed = false;
        lastPressedButton = null;

        while (!buttonPressed) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (lastPressedButton == Button.Y) {
            System.out.println("Starting a new round...");
            return true;
        } else if (lastPressedButton == Button.X) {
            System.out.println("\nExiting game. Thanks for playing!");
            System.out.println("\nGame Over!");
            System.out.println("Final Scores: ");
            System.out.println("Player's Score: " + playerScore);
            System.out.println("Computer's Score: " + computerScore);

            logFinalResults(); // Save final results in log file
            return false;
        } else {
            System.out.println("Invalid button pressed! Please press 'Y' to continue or 'X' to exit.");
            return promptContinue(); // Retry input
        }
    }

    private void logFinalResults() {
        File logFile = new File("game_log.txt");

        try (FileWriter writer = new FileWriter(logFile, true)) {
            writer.write("\nGame Over!\n");
            writer.write("Final Scores: \n");
            writer.write("Player's Score: " + playerScore + "\n");
            writer.write("Computer's Score: " + computerScore + "\n");
        } catch (IOException e) {
            System.err.println("Error logging final results: " + e.getMessage());
        }
    }

    private void logGameResult(int round, String secretCode, String playerGuess, int maxGuesses, int guessesLeft) {
        File logFile = new File("game_log.txt");

        try (FileWriter writer = new FileWriter(logFile, true)) {
            writer.write("Round: " + round + "\n");
            writer.write("Computer's Code: " + secretCode + "\n");
            writer.write("Player's Guess: " + (playerGuess != null ? playerGuess : "N/A") + "\n");
            writer.write("Score: " + playerScore + "-" + computerScore + "\n");
            writer.write("Total Guesses: " + maxGuesses + "\n");
            writer.write("Guesses Left: " + guessesLeft + "\n\n");
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
            System.out.println("Game continues without logging this round.");
        }
    }
}


